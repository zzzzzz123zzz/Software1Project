import components.simplereader.SimpleReader;
import components.simplereader.SimpleReader1L;
import components.simplewriter.SimpleWriter;
import components.simplewriter.SimpleWriter1L;

/**
 * This program calculates the square root of a positive number (including 0)
 * using Newton's method with a user-defined relative error threshold (epsilon).
 * The user can perform multiple calculations in a single session.
 *
 * @author Jeng Zhuang
 *
 */
public final class Newton3 {

    /**
     * No argument constructor--private to prevent instantiation.
     */
    private Newton3() {
    }

    /**
     * Computes estimate of square root of x to within relative error 0.01%.
     *
     * @param x
     *            positive number to compute square root of
     * @param epsilon
     *            the relative error threshold
     * @return estimate of square root
     */
    private static double sqrt(double x, double epsilon) {
        double r = x; // initial Guess

        // Special case for x = 0; its square root is 0
        if (x == 0) {
            return r;
        } else {
            // Iteratively refine the estimate until the relative error is within bounds
            while (Math.abs(r * r - x) / x >= epsilon * epsilon) {
                r = (r + x / r) / 2;
            }
            return r;
        }
    }

    /**
     * Main method.
     *
     * @param args
     *            the command line arguments
     */
    public static void main(String[] args) {
        SimpleReader in = new SimpleReader1L();
        SimpleWriter out = new SimpleWriter1L();

        // Ask the user for epsilon value
        out.print("Please enter the value of epsilon: ");
        double epsilon = in.nextDouble();

        // Prompt the user to start calculating square roots
        out.print("Do you want to calculate a square root? (y/n): ");
        String response = in.nextLine();

        // Loop to allow multiple calculations
        while (response.equals("y")) {
            out.print("Please enter a positive number: ");
            double x = in.nextDouble();

            // Compute the square root using the sqrt method
            double result = sqrt(x, epsilon);
            out.println("The square root of " + x + " is approximately " + result);

            // Ask if the user wants to perform another calculation
            out.print("Do you want to calculate another square root? (y/n): ");
            response = in.nextLine();

        }

        /*
         * Close input and output streams
         */
        in.close();
        out.close();
    }

}
